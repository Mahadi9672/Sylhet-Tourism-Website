<!DOCTYPE html>
<html>
<head>
	<title>Sylhet Tourism Website</title>
	<link rel="stylesheet" href="style.css">
</head>
<body>
	<div id="tour">
	<header>
		<div id="header">
			<center>
			<h1 style="text-decoration:none;">Sylhet Tourism Website</h1>
			</center>
		</div>
	</header>
	<nav>
          <div id="nav">
			 <ul>
                <li><a href="Tour Package.php">Tour Package List</a></li>
                <li><a href="Booking.php">Booking</a></li>
                <li><a href="Notice.php">Notice</a></li>
                <li><a href="index.php">Logout</a></li>
               
              </ul>
		</div>
	</nav>
</div>
</body>
</html>