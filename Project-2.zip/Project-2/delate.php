<?php
    session_start();
	$con=mysqli_connect('localhost:3307','root','');
	mysqli_select_db($con,'project-2');


	$tno=$_GET['rn'];
	$query="delete from tp where tno='$tno'";
	$data=mysqli_query($con,$query);
	if($data){
	echo "Record deleted form database";
	}
	else{
	echo "Failed to delete";
	}
	?>