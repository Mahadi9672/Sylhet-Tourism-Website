<!DOCTYPE html>
<html>
<head>
	<title>Admin Page One</title>
	<link rel="stylesheet" href="Admin Page1.css">
</head>
<body>
<div>
	<center>
	<h1>Welcome to Admin Pages</h1>
    <button class="button"><a href="Admin Page.php">Add Package</a></button><br><br>
	<button class="button"><a href="delate package.php">Delete Package</a></button><br><br>
	<button class="button"><a href="index.php">Logout</a></button><br><br>
	</center>
</div>
</body>
</html>