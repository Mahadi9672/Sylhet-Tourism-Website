<!DOCTYPE html>
<html>
<head>
	<title>Sylhet Tourism Website</title>
	<link rel="stylesheet" href="style.css">
</head>
<body>
	<div id="tour">
	<header>
		<div id="header">
			<center>
			<h1>Sylhet Tourism Website</h1>
			</center>
		</div>
	</header>
	<nav>
           <div id="nav">
			 <ul>
               <li><a href="index.php">Home</a></li>
               <li><a href="Gallery.php">Gallery</a></li>
               <li><a href="#">Place</a>
               <ul>
                    <li><a href="Ratargul.php">Ratargul</a></li>
                    <li><a href="Lalakhal.php">Lalakhal</a></li>
                    <li><a href="Tanguar Hoar.php">Tanguar Haor</a></li>
                    <li><a href="Panthumai.php">Panthumai</a></li>
                    <li><a href="Bisnakandi.php">Bisnakandi</a></li>
                    <li><a href="Jaflong.php">Jaflong</a></li>
                    <li><a href="Jadukata.php">Jadukata</a></li>
                    <li><a href="Bholagonj.php">Bholagonj</a></li>
                    <li><a href="Lawachera.php">Lawachera</a></li>
                    <li><a href="Rema Kalenga.php">Rema Kalenga Reserve Forest</a></li>
                    <li><a href="Sathchori.php">Sathchori National Forest</a></li>
                </ul>
                </li>
                <li><a href="Login.php"> User Login</a></li>
                <li><a href="Admin.php"> Admin Login</a></li>
                <li><a href="Contact.php">Contact Us</a></li>
				</ul>
		</div>
	</nav>
	<section>
		<div id="section">
		<img src="Keane_Bridge.jpg" alt="demo">
		</div>
	</section>

	<div id="info">
		   <h1>Welcome To Visit Beautiful Sylhet City</h1>
		   <p>Sylhet is a metropolitan city in northeastern Bangladesh.It is the administrative seat of Sylhet Division.The city is located on the right back of the Surma River in northeastern Bengal.It has a subtropical climate and lush highland terrain.The city has a population of more the half a million.Sylhet is one of Bangladesh's most important spiritual and cultural centres.It is one of the most important cities of Bangladesh,after Dhaka and Chittagong due to its important to the country's economy.<br>Sylhet produces the highest amount of tea and gas in the country.</p>
		 </div>

		 
            <footer>
		    <div id="footer">
			<p>All Copyrights Reserved #2020 &copy;Sylhet Tourism Website</p>
			</div>
			</footer>

			<div class="icon">
	        <h3>Follow Us:</h3>
			<ul class="social">
                <li><a href="#"><img src="image/facebook.jpg" alt="facebook share"></a></li>
				<li><a href="#"><img src="image/instragram.jpg" alt="instragram share"></a></li>
				<li><a href="#"><img src="image/linkedin.jpg" alt="linkedin share"></a></li>
				<li><a href="#"><img src="image/gmail.jpg" alt="gmail share"></a></li>
				<li><a href="#"><img src="image/twitter.jpg" alt="twitter share"></a></li>
			</ul>
			</div>
            
			
	</div>
</body>
</html>
