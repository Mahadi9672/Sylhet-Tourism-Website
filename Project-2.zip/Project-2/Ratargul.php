<?php include('header.php');?>
<!DOCTYPE html>
<html>
<head>
	<title>Ratargul Place</title>
	<link rel="stylesheet" href="Ratargul.css">
</head>
<body>
	<div id="slider">
	 
    </div>
    <h1>Welcome to Ratargul Swamp Forest</h1>
    
    <h2>Place Introduction:</h2>
    <p>Ratargul Swamp Forset is a heavenly tourist attraction in Sylhet.Covering about 504 acres of land,Ratargul forest connects with Chengir Lake and Gowain River.This forest is composed of diverse kinds of water plants.What makes Ratargul forest exclusive is the amazing beauty of standing trees over the water.During the rainy season,this forest is submerged with 20-30 feet water.Then it looks like the trees and their shadows have divided the crystal water.The marvelous greenery of surrounding Mizoram hills is merged with the eternal beauty of this serene forest.</p>     
   <h2>How to reach Ratargul Swamp Forest from Sylhet City?</h2>
   <p>First you can hire a CNG-fare range around 500 BDT from Sylhet city to arrive at Goain Ghat.The journey usually takes about 2.5 to 3 hours.Form Goain Ghat,you can reserve a trawler engine boat to explore the Ratargul Swamp Forest.</p>
   	
   

</body>
</html>