<?php
	session_start();
	$con=mysqli_connect('localhost:3307','root','');
	mysqli_select_db($con,'project-2');
	
	if(isset($_POST['submit']))
	{
		$a=$_POST['place'];
		$b=$_POST['duration'];
		$c=$_POST['price'];
		$d=$_POST['ldate'];
		$e=$_POST['trn'];
		$f=$_POST['des'];
		$g=$_POST['seat'];
		$qry="INSERT INTO tp (place, duration, price, ldate, trn,des,seat) VALUES( '$a','$b','$c','$d','$e','$f','$g')";
		mysqli_query($con,$qry);
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Admin Pages</title>
	<link rel="stylesheet" href="Admin Page.css">
</head>
<body>

	<div class="admin">
		   <h1>ADD PACKAGES</h1>
		   <form method="post">
                <input type="text" name="place" placeholder="Place" required><br><br>
				<input type="text" name="duration" placeholder="Duration" required><br><br>
				<input type="text" name="price" placeholder="Price" required><br><br>
				<input type="text" name="ldate" placeholder="Last Date" required><br><br>
				<input type="text" name="trn" placeholder="Transport" required><br><br>
				<input type="text" name="des" placeholder="Description" required><br><br>
				<input type="text" name="seat" placeholder="Total Seats" required><br><br>
				<input type="submit" name="submit" placeholder="Add Package" required><br><br>
				
				
			</form>
	</div>

</body>
</html>