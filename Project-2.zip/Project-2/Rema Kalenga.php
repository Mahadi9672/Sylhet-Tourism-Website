<?php include('header.php');?>
<!DOCTYPE html>
<html>
<head>
	<title>Rema Kalenga</title>
	<link rel="stylesheet" href="Rema Kalenga.css">
</head>
<body>
	<div id="slider">
	
    </div>
    <h1>Welcome to Visit Rema Kalenga Beautiful Places.</h1>
    <h2>Place Introduction:</h2>
    <p> Rema Kalenga is the largest natural forest after the Sundarbans in Bangladesh. A sanctuary for wild animals, this dry forest has been declared as ‘Reserve Forest’ by the government. Though Rema and Kalenga are two different forests, they are closely connected.


    Besides the deep forest and wild animals, tourists will be greeted by indigenous communities such as Tripura, Munda, and Oraw who have been living there for ages.

   A watch tower and a natural lake are the added attractions at Kalenga besides the grave of Bir Uttham Abdul Mannan who embraced martyrdom while fighting in the Liberation War.

   Rema-Kalenga Reserve Forest is extremely popular with animal lovers as well. Anyone visiting this forest may encounter various species of apes, squirrels, deer, tigers, elephants, wild dogs and pigs besides a host of birds including parrots, magpies, owls, kingfishers, eagles and sea gulls. </p>
   
  <h2>How to reach Rema Kalenga from Sylhet City?</h2>
  <p>Anyone travelling from Dhaka has to take the road to Chunnarughat from General M A Rob Circle past Shayestagonj. After reaching Chunnarughat, s/he can ask anyone there to show the way to Rema-Kalenga. The 15 km narrow road, which passes through green paddy fields, is ok except for the last three kilometres, which is unpaved. In the rainy season, it is a good idea to hire a CNG-run auto-rickshaw rather than drive there. However, in winter it is possible to drive to the entry of the forest. Apart from that, tourists can also go to Kalenga from Sreemongol through a hilly road. Well trained local guides are there to take tourists through the forest. With its 30-minute, one-hour, three-hour and one-day trails, Rema-Kalenga Reserve Forest is a paradise for trekkers. </p>

</body>
</html>