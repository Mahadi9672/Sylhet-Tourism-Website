<?php
	session_start();
	$con=mysqli_connect('localhost:3307','root','');
	mysqli_select_db($con,'project-2');
	
	if(isset($_POST['submit']))
	{
		$a=$_POST['tour_no'];
		$b=$_POST['place'];
		$c=$_POST['tdes'];
		$d=$_POST['seat'];
		
		$qry="INSERT INTO notice (tour no,place,tdes,seat) VALUES( '$a','$b','$c','$d' )";
		mysqli_query($con,$qry);
	}
?>
















<body>
	<form method="post">
                <input type="text" name="tour_no" placeholder="Tour Number" required><br><br>
				<input type="text" name="place" placeholder="Place" required><br><br>
				<input type="text" name="tdes" placeholder="Place Description" required><br><br>
				<input type="text" name="seat" placeholder="Total Seat" required><br><br>
				
				<input type="submit" name="submit" placeholder="Add Notice" required><br><br>
				
				
			</form>
</body>