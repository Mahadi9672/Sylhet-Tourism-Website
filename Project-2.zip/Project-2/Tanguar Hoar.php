<?php include('header.php');?>
<!DOCTYPE html>
<html>
<head>
	<title>Tanguar Hoar</title>
	<link rel="stylesheet" href="Tanguar Hoar.css">
</head>
<body>
	<div id="slider">
	</div>
	
    <h1>Welcome to Visit Tanguar Hoar Beautiful Places.</h1>
    <h2>Place Introduction:</h2>
    <p>At the foot of the Meghalaya ranges in the middle of Tahirpur and Dharmapasha Upazilla under Sunamgonj district in north-east Sylhet is a vast swampland popularly known as Tangoar Haor that spans over an area of nearly 100 square kilometres. Cascading from the Meghalaya about 30 waterfalls flow into this large water body engendering a charm that is truly rare. In 2000, it was internationally recognised as a Ramseur site. After the Sundarbans, it is the second Ramseur site in Bangladesh. Prior to that, in 1999, the government of Bangladesh earmarked Tangoar Haor as an ecologically critical area.</p>

    <h2>How to reach Tanguar Hoar from Sylhet City?</h2>
    <p>In winter tourists can hire motor bikes from Shaheb-bari Kheyaghat in Sunamganj and go to Tahirpur or Takerghat in a couple of hours. From either of the places a boat may be hired to roam about Tangoar Haor. In the rainy season, many tourists hire a bojra – a spacious mechanised local boat suitable for overnight stay – from Sunamgonj to visit Tangoar Haor. Hiring a bojra costs about 10,000 BDT a day. However, it is not a good idea to visit Tangoar Haor in the rainy season without a life jacket and other necessary precautions in view of the rough, wavy waterline, despite the unparalleled splendour that this large water body exhibits in this season.

    The best option is to hire a launch (a steamer-like engine-operated boat) from Sunamganj, travel to Tangoar Haor via Tahirpur and finally reach Takerghat, which is a Bangladeshi limestone mine at the foot of the Meghalayan ranges currently lying in an abandoned state. </p>

</body>
</html>