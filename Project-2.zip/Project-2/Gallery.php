<?php include('header.php');?>
<!DOCTYPE html>
<html>
<head>
	<title>Website Gallery</title>
	<link rel="stylesheet" type="text/css" href="Gallery.css">
</head>
<body>
	<h2>Place Image Gallery</h2><br>
<div class="Gallery">
   <img src="image/Ratargul/1.jpg">
   <img src="image/Ratargul/2.jpg">
   <img src="image/Ratargul/3.jpg">
   <img src="image/Ratargul/4.jpg">
   <img src="image/Ratargul/5.jpg">
   <img src="image/Bholagonj/1.jpg">
   <img src="image/Bholagonj/2.jpg">
   <img src="image/Bholagonj/3.jpg">
   <img src="image/Bholagonj/4.jpg">
   <img src="image/Bholagonj/5.jpg">
   <img src="image/Bisnakandi/1.jpg">
   <img src="image/Bisnakandi/2.jpg"> 
   <img src="image/Bisnakandi/3.jpg"> 
   <img src="image/Bisnakandi/4.jpg"> 
   <img src="image/Jaflong/1.jpg"> 
   <img src="image/Jaflong/2.jpg">
   <img src="image/Jaflong/3.jpg"> 
   <img src="image/Jaflong/4.jpg"> 
   <img src="image/Jaflong/5.jpg"> 
   <img src="image/Jaflong/6.jpg"> 
   <img src="image/Jaflong/7.jpg">  
   <img src="image/Tanguar Haor/1.jpg"> 
   <img src="image/Tanguar Haor/2.jpg">
   <img src="image/Tanguar Haor/3.jpg">
   <img src="image/Tanguar Haor/4.jpg">
   <img src="image/Tanguar Haor/5.jpg">
   <img src="image/Tanguar Haor/6.jpg">
   <img src="image/Jadukata/1.jpg">
   <img src="image/Jadukata/2.jpg">
   <img src="image/Jadukata/3.jpg">
   <img src="image/Jadukata/4.jpg">
   <img src="image/Lalakhal/1.jpg">
   <img src="image/Lalakhal/2.jpg">
   <img src="image/Lalakhal/3.jpg">
   <img src="image/Lalakhal/4.jpg">
   <img src="image/Lawachera/1.jpg">
   <img src="image/Lawachera/2.jpg">
   <img src="image/Lawachera/3.jpg">
   <img src="image/Lawachera/4.jpg">
   <img src="image/Panthumai/1.jpg">
   <img src="image/Panthumai/2.jpg">
   <img src="image/Panthumai/3.jpg">
   <img src="image/Panthumai/4.jpg">
   <img src="image/Rema Kalenga/1.jpg">
   <img src="image/Rema Kalenga/2.jpg">
   <img src="image/Rema Kalenga/3.jpg">
   <img src="image/Rema Kalenga/4.jpg">
   <img src="image/Rema Kalenga/5.jpg">
   <img src="image/Rema Kalenga/6.jpg">
   <img src="image/Sathchori/1.jpg">
   <img src="image/Sathchori/2.jpg">
   <img src="image/Sathchori/3.jpg">
   <img src="image/Sathchori/4.jpg">
   <img src="image/Sathchori/5.jpg">
   <img src="image/Sathchori/6.jpg">
   <img src="image/Sathchori/4.jpg">



   
 </div>
</body>
</html>