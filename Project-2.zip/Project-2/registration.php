<?php
session_start();
$con=mysqli_connect('localhost:3307','root','');
mysqli_select_db($con,'project-2');
$fname=$_POST['fname'];
$lname=$_POST['lname'];
$uname=$_POST['uname'];
$email=$_POST['email'];
$password=$_POST['password'];

$s="select * from register where uname='$uname'";
$result=mysqli_query($con,$s);
$num=mysqli_num_rows($result);

if($num==1){
	echo "User Name Already Taken .Try with another one ";
}	
else{
    $rr="insert into register(fname,lname,uname,email,password) values ('$fname','$lname','$uname','$email','$password')";
	mysqli_query($con,$rr);
	echo "Registration Successful";
}
?>