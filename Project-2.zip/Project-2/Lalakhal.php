<?php include('header.php');?>
<!DOCTYPE html>
<html>
<head>
	<title>Lalakhal Place</title>
	<link rel="stylesheet" href="Lalakhal.css">
</head>
<body>
	<div id="slider">
	</div>
    <h1>Welcome to Visit Lalakhal Beautiful Places.</h1>
    <h1>Best time to visit Lalakhal:</h1>
    <h2>Place Introduction:</h2>
    <p>Lalakhal is Tourist Spot in Sylhet,Bangladesh.Lalakhal is a wide channel in the Sharee River near the Tamabil road.<br>The river is not very deep and is one of the sources of sand in Sylhet.The focal point of the feature is the varity of colours of the water,which varies from blue to green to clear at different points.</p>        
    <h2>How to reach Lalakhal from Sylhet City?</h2>
    <p>First get on a bus to arrive at Sarighat-42km distant from Sylhet City.Here you would find reserve boats.Now,you can step on this heaven on earth through a boat ride.The amazing beauty of Lalakhal would keep you enthralled throughout the journey.The greenish blue crystal water of Lalakhal creates a breathtaking combo with cloud touching hills and surrounding greenery.</p>
   	
   

</body>
</html>