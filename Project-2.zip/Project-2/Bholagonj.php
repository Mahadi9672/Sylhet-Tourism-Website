<?php include('header.php');?>
<!DOCTYPE html>
<html>
<head>
	<title>Bholagonj</title>
	<link rel="stylesheet" href="Bholagonj.css">
</head>
<body>
	<div id="slider">
	
    </div>
    <h1>Welcome to Visit Bholagonj Beautiful Place</h1>
	<h2>Place Introduction:</h2>
    <p>
    	Bholagonj, the largest stone quarry in Bangladesh, is 33 km away to the north from Sylhet city. Flowing respectively from the Khasi hill in the north and Dauki in the east, the rivers Dholai and the Piyain meet at Companigonj Upazilla Sadar, which is 27 km away from Sylhet city on the Salutikor-Bholagonj Road. Just six kilometres from there is Bholagonj— a place that boasts of rows of hills, rivers, falls and quarries. 
    </p>
    <h2>How to reach Bisnakandi from Sylhet City?</h2>
    <p>Though it is only 33 km away from Sylhet it takes about an hour and a half to reach Bholagonj due to the poor condition of the road. CNG-run auto-rickshaws are available from Amberkhana Point and the fare is 120 BDT per person. Private cars are not suggested due to road condition.</p>

</body>
</html>