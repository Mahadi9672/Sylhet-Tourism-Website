<!DOCTYPE html>
<html>
<head>
	<title>Sylhet Tourism Website</title>
	<link rel="stylesheet" href="style.css">
</head>
<body>
	<div id="tour">
	<header>
		<div id="header">
			<center>
			<h1>Sylhet Tourism Website</h1>
			</center>
		</div>
	</header>
	<nav>
          <div id="nav">
			 <ul>
                <li><a href="Tour Package.php">Tour Package List</a></li>
                <li><a href="Booking.php">Booking</a></li>
                <li><a href="Notice.php">Notice</a></li>
                <li><a href="index.php">Logout</a></li>
               
              </ul>
		</div>
	</nav>
	<section>
		<div id="section">
		<img src="Keane_Bridge.jpg" alt="demo">
		</div>
	</section>

	<div id="info">
		   <h1>Welcome To Visit Beautiful Sylhet City</h1>
		   <p>Sylhet is a metropolitan city in northeastern Bangladesh.It is the administrative seat of Sylhet Division.The city is located on the right back of the Surma River in northeastern Bengal.It has a subtropical climate and lush highland terrain.The city has a population of more the half a million.Sylhet is one of Bangladesh's most important spiritual and cultural centres.It is one of the most important cities of Bangladesh,after Dhaka and Chittagong due to its important to the country's economy.<br>Sylhet produces the highest amount of tea and gas in the country.</p>
		 </div>

		    <footer>
		    <div id="footer">
			<p>All Copyrights Reserved #2020 &copy;Sylhet Tourism Website</p>
			</div>
			</footer>

	

		 
           
			
	</div>
</body>
</html>
