<?php include('header.php');?>
<!DOCTYPE html>
<html>
<head>
	<title>Jaflong</title>
	<link rel="stylesheet" href="Jaflong.css">
</head>
<body>
	<div id="slider">

	</div>
	<div id="details">
	<h1>Welcome To Visit Jaflong</h1>
	<h1>Best Time to visit Jaflong place: April To October</h1>
	<h2>Place Introduction :</h2>
	<p>Jaflong is a hill station and tourist destination in the Division of Sylhet,Bangladesh. It is located in Gowainghat Upazila of Sylhet District and situated at the border between Bangladesh and the Indian state of Meghalaya,overshadowed by subtropical mountains and rainforests.It is known for its stone collection and is home of the Khasi tribe.Jaflong located amidst tea gardens and hills.It is situated beside the river Sari in the lap of Hill Khashia.</p>
	
    <h2>How to reach Jaflong from Sylhet City?</h2>
 
     <p>The distance from Sylhet city to jaflong is about 62km.You can take a bus from Sylhet city heading towards jaflong directly.The journey takes about 2 to 2.5 hours.<br><br>
     Hiring a boat in jaflong, you can visit Zero Point,the last border of Bangladesh.The most amazing attraction of jaflong is a natural bridge hanging over the river Dauki.Here you can also enjoy the magnificent water falls flowing from distant green mountains.</p>
   </div>
  


</body>
</html>