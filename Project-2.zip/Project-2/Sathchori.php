<?php include('header.php');?>
<!DOCTYPE html>
<html>
<head>
	<title>Sathchori</title>
	<link rel="stylesheet" href="Sathchori.css">
</head>
<body>
	<div id="slider">
	
    </div>
    <h1>Welcome to Visit Rema Kalenga Beautiful Places.</h1>
    <h2>Place Introduction:</h2>
    <p>

    Sathchori National ForestSathchori National Forest is situated in Roghunandon Hill at Chunnarughat Upazilla under Habiganj District in Sylhet Division. Previously known as Roghunandon Reserve Forest, this national forest partitions Sathchori Tea Garden and Chaklapunji Tea Garden. There are some other tea gardens near the forest which was actually named after seven choras (creeks) flowing from the hills.

   Sathchori National Forest is mainly an evergreen woodland boasting of almost 200 types of trees including teakwood (tectona grandis), mahogany (swietenia mahagoni) chrysanthemum and bamboo. In addition to a variety of species of apes and deer, 24 species of mammals, 18 species of reptiles and 150 types of birds are found there.

   There are three trails for trekking. One takes 30 minutes, another one hour and the other three hours to complete trekking. The 30-minute trail takes one to the village of the Tripura indigenous community. The three-hour trail, which is six kilometres long, is ideal for anyone interested in birds and wild animals as well as agar wood (raw material for incense and perfume). There are some well trained guides to take tourists through the forest.</p>
   
   <h2>How to reach Rema Kalenga from Sylhet City?</h2>
   <p>Tourists travelling from Dhaka should take the Dhaka-Sylhet highway and turn right at Sayham Circle in Madhobpur. It is also possible to travel to Sreemongol first, and then to go to Sathchori. It is also accessable from Chunaroghat.</p>

</body>
</html>