<?php include('header.php');?>
<!DOCTYPE html>
<html>
<head>
	<title>Jadukata</title>
	<link rel="stylesheet" href="Jadukata.css">
</head>
<body>
	<div id="slider">
	
    </div>
    <h1>Welcome to Visit Jadukata Beautiful Places.</h1>
    <h2>Place Introduction:</h2>
    <p>Bangladesh is crisscrossed by rivers, and beautiful rivers are always an attraction for tourists. The Jadukata – one of the most beautiful rivers in Bangladesh – is situated in Laurergorh under Tahirpur Upazilla in Sunamgonj District. Previously called the Renuka, this river flows from the Meghalaya ranges. The shrine of Hazrat Shah Arefin (R) is situated beside the river. Spectacularly visible behind the shrine (in the rainy season) is a waterfall. On the other side of the river is a beautiful hill popularly known as Bariker Tilla, behind which there is a church. Beside the church is a narrow westward road that leads to the village of the Garo indigenous community. Past the Garo village is the Borochora Stone Quarry and Takerghat. </p>

    <h2>How to reach Jadukata from Sylhet City?</h2>
    <p>In winter, tourists can hire a motor bike at Shaheb-bari to go to Bariker Tilla. They can also move further ahead and go to Takerghat, from where a boat may be hired to roam about Tangoar Haor.

    Anyone visiting Tangoar Haor in the rainy season by bojra may hire a motor bike at Takerghat to go to the Jadukata River and Bariker Tilla. </p>

</body>
</html>