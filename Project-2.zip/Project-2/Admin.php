<!DOCTYPE html>
<html>
<head>
	<title>Admin Pages</title>
	<link rel="stylesheet" href="Admin.css">
</head>
<body>
	<div class="login">
				<form action="head.php" method="post">
					<center>
					<h1>Login Here</h1>
					<label>Username</label><br>
					<input type="text" name="username" id="user" required><br><br>
					<label>Password</label><br>
					<input type="Password" name="password" id="pass" required><br><br>
                    <input type="submit" name="submit">
				</form>
				</center>
			</div>
				
	

</body>
</html>