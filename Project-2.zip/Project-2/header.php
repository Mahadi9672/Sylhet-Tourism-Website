<!DOCTYPE html>
<html>
<head>
	<title>Sylhet Tourism Website</title>
	<link rel="stylesheet" href="style.css">
</head>
<body>
	<div id="tour">
	<header>
		<div id="header">
			<center>
			<h1>Sylhet Tourism Website</h1>
			</center>
		</div>
	</header>
	<nav>
           <div id="nav">
			 <ul>
               <li><a href="index.php">Home</a></li>
               <li><a href="Gallery.php">Gallery</a></li>
               <li><a href="#">Place</a>
               <ul>
                    <li><a href="Ratargul.php">Ratargul</a></li>
                    <li><a href="Lalakhal.php">Lalakhal</a></li>
                    <li><a href="Tanguar Hoar.php">Tanguar Haor</a></li>
                    <li><a href="Panthumai.php">Panthumai</a></li>
                    <li><a href="Bisnakandi.php">Bisnakandi</a></li>
                    <li><a href="Jaflong.php">Jaflong</a></li>
                    <li><a href="Jadukata.php">Jadukata</a></li>
                    <li><a href="Bholagonj.php">Bholagonj</a></li>
                    <li><a href="Lawachera.php">Lawachera</a></li>
                    <li><a href="Rema Kalenga.php">Rema Kalenga Reserve Forest</a></li>
                    <li><a href="Sathchori.php">Sathchori National Forest</a></li>
                </ul>
                </li>
                <li><a href="Login.php">Login</a></li>
                <li><a href="Admin.php">Admin Login</a></li>
                <li><a href="Contact.php">Contact Us</a></li>
              </ul>
		</div>
	</nav>
		</div>
</body>
</html>