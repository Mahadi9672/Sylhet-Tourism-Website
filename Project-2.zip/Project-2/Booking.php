<?php include('header1.php');?>

<!DOCTYPE html>
<html>
<head>
	<title>Booking Package</title>
	<link rel="stylesheet" type="text/css" href="Booking.css">
</head>
<body>
	<div class="booking-title">
		<h1>Please Booking Your Tour Package</h1>
	</div>
		 <div class="form">
		 	<form id="booking-form" action="Confirm.php" method="post">
		 		<input class="form-input" name="tour_no" placeholder="Enter Tour No" required><br>
		 		<input type="text" name="name" class="form-input" placeholder="Your Name" required><br>
		 		<input type="text" name="mobile" class="form-input" placeholder="Your Mobile Number" required><br>
		 		<input type="email" name="email" class="form-input" placeholder="Your Email ID" required><br>
		 		<input type="submit" class="form-input submit" value="Confirm Booking">
		 	</form>
		 	


		 </div> 

</body>
</html>