<?php include('header.php');?>
<!DOCTYPE html>
<html>
<head>
	<title>Login And Signup Form</title>
	<link rel="stylesheet" type="text/css" href="Login.css">
</head>
<body>
	<div class="login">
		<div class="form-box">
			<div class="button-box">
				<div id="btn"></div>
				<button type="button" class="toggle-btn" onclick="login()" >Log In</button>
				<button type="button" class="toggle-btn" onclick="register()">Sign Up</button>
				</div>

			    <form id="login" class="Login-input" action="validation.php" method="post">
				<input type="text"  name="user" class="input-field" placeholder="User Name" required>
				<input type="text"  name="Password" class="input-field" placeholder="Enter Password" required><br><br> 
				<br>
				<button type="submit" class="submit-btn">Log In</button>
			    </form>

			    <form id="register" class="Signup-input" action="registration.php" method="post" >
				<input type="text"  name="fname" class="input-field" placeholder="Frist Name" required>
				<input type="text"  name="lname" class="input-field" placeholder="Last Name" required>
				<input type="text"  name="uname" class="input-field" placeholder="User Name" required>
				<input type="email" name="email" class="input-field" placeholder="Email ID" required>
				<input type="text"  name="password" class="input-field" placeholder="Enter Password" required>
			

				<input type="checkbox" class="chech-box"><span>I agree to the terms  conditions</span>
				<button type="submit" class="submit-btn">Sign Up</button>
			</form>
			
</div>
</div>
<script>
	var x=document.getElementById("login");
	var y=document.getElementById("register");
	var z=document.getElementById("btn");

	function register(){
		x.style.left="-400px";
		y.style.left="50px";
		z.style.left="100px";
	}
	function login(){
		x.style.left="50px";
		y.style.left="450px";
		z.style.left="0px";
	}
</script>

</body>
</html>