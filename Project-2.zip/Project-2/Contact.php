<?php include('header.php');?>
<!DOCTYPE html>
<html>
<head>
	<title>Contact</title>
	<link rel="stylesheet" type="text/css" href="Contact.css">
</head>
<body>
	<div class="contact-title">
		<h2>Contact US</h2>
		</div>
		 <div class="form">
		 	<form id="contact-form " action="Store.php" method="post">
		 		<input type="text" name="name" class="form-input" placeholder="Your Name" required><br>
		 		<input type="email" name="email" class="form-input" placeholder="Your Email ID" required><br>
		 		<textarea type="message" name="message" rows="3" class="form-input" placeholder="Write Your Message" required></textarea><br>
                <input type="submit"class="form-input submit" value="SEND MESSAGE">
		 	</form>
		 	


		 </div>

</body>
</html>