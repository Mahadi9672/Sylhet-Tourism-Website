<?php include('header1.php');?>
<?php
	session_start();
	$con=mysqli_connect('localhost:3307','root','');
	mysqli_select_db($con,'project-2');
?>

<!DOCTYPE html>
<html>
<head>
	<title>Tour Package List</title>
	<link rel="stylesheet" type="text/css" href="Tour Package.css">
</head>
<body>
	<br>
    <h2>TOUR PACKAGE SCHEDULES</h2><br>
    <h2>UPCOMING.....</h2><br>
    
	<table>
    <tr>
		<th>Tour No</th> 
		<th>Place</th>
		<th>Duration</th>
		<th>Price</th>
		<th>Booking Last Date</th>
		<th>Transport</th>
		<th>Booking</th>
		
		
    </tr>
	<?php
		$qry="select * from tp";
		$result=mysqli_query($con,$qry);
		while($row=mysqli_fetch_assoc($result)){
	?>	
	<tr>
		<th><?php echo $row['tno']; ?></th> 
		<th><?php echo $row['place']; ?></th>
		<th><?php echo $row['duration']; ?></th>
		<th><?php echo $row['price'];?></th>
		<th><?php echo $row['ldate'];?></th>
		<th><?php echo $row['trn'];?></th>
		
		<th>
			<a href="Booking.php">Booking</a>
		</th>
		

    </tr>
		<?php
		}
		?>
	</table>



</body>
</html>