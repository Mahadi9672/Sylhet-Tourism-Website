<?php
session_start();
$con=mysqli_connect('localhost:3307','root','');
mysqli_select_db($con,'project-2');
$tour_no=$_POST['tour_no'];
$name=$_POST['name'];
$email=$_POST['email'];
$mobile=$_POST['mobile'];
$s="select * from booking where mobile='$mobile'";
$result=mysqli_query($con,$s);
$rr="insert into booking(tour_no,name,email,mobile) values ('$tour_no','$name','$email','$mobile')";
mysqli_query($con,$rr);
echo "<h1>Tour Package Booking Successfully</h1>";

?>