<?php include('header.php');?>
<!DOCTYPE html>
<html>
<head>
	<title>Lawachera</title>
	<link rel="stylesheet" href="Lawachera.css">
</head>
<body>
	<div id="slider">
	
    </div>
    <h1>Welcome to Visit Bholagonj Beautiful Place</h1>
	<h2>Place Introduction:</h2>
    <p>On the Vanugach-Komalganj Road about seven kilometres from Sreemongol town is the entry to Lauachora National Garden. It is an evergreen rainforest with excessive precipitation. Tall trees with their lofty branches and soaring foliage make for a unique cover for the forest on a sunny day. Lauachora is one of the seven safari parks and 10 national gardens in Bangladesh. An area of 1,250 hectares from the 2,740-hectare West Vanugach Reserve Forest was declared a national garden in 1996. </p>
    <h2>How to reach Jaflong from Sylhet City?</h2>
    <p>Lawachera is easily accessible from sreemongol town by own drive or cng auto rickshaw. Tourist may come to sreemongol from Dhaka or Sylhet by car or train. </p>

</body>
</html>