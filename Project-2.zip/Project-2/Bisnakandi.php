<?php include('header.php');?>
<!DOCTYPE html>
<html>
<head>
	<title>Bisnakandi</title>
	<link rel="stylesheet" href="Bisnakandi.css">
</head>
<body>
	<div id="slider">
	</div>
	<h1>Welcome to Visit Bisnakandi</h1>
	<h1>Best time to visit Bisnakandi Place:</h1>

	<h2>Place Introduction:</h2>
	<p>The Bisnakandi village falls under Rustompur Union at Guainghat Upazilla in Sylhet.Bisnakandi presents a unique natural beauty where several layers of Khasi Mountain summits at a single peak from different sides.While following from the high mountains,the river stream carries huge rocks which naturally get deposite in Bisnakandi.The rolling stones lying over crystal clear water would leave an unforgettable memory in your mind.</p>

	<h2>How to reach Bisnakandi from Sylhet City?</h2>
	<p>Bisnakandi is about 25 kilometers far from Sylhet City.There are several ways to reach Bisnakandi from Sylhet City.You can take a CNG or Auto-Rickshaw to arrive at Hadarpar.On this point you can reserve a local boat to explore Bisnakandi.<br><br>During your boat-journey to Bisnakandi ,the boat will travel across the heavenly beautiful Piyain River.On the way,you can enjoy the cherubic sceneries of cloud-hugging mountain views,sinuous falls and graceful rural landscape.The best view of Bisnakandi are found during the rainy season.</p>


</body>
</html>