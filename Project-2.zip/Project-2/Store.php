<?php
session_start();
$con=mysqli_connect('localhost:3307','root','');
mysqli_select_db($con,'project-2');
$name=$_POST['name'];
$email=$_POST['email'];
$message=$_POST['message'];

$s="select * from contact where email='$email'";
$result=mysqli_query($con,$s);
    $rr="insert into contact(name,email,message) values ('$name','$email','$message')";
	mysqli_query($con,$rr);
	echo "<h1>Your Request Sent Successfully</h1>";

?>