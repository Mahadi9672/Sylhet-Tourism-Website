<?php
session_start();
$con=mysqli_connect('localhost:3307','root','');
mysqli_select_db($con,'project-2');

$user=$_POST['user'];
$password=$_POST['Password'];

$s="select * from register where uname='$user' && Password='$password'";
$result=mysqli_query($con,$s);
$num=mysqli_num_rows($result);

if($num==1){
	$n=mysqli_query($con,"select * from register where uname='$user' && Password='$password'");
	$row=mysqli_fetch_assoc($n);
	$nnn=$row['fname'];
	$_SESSION['name']=$nnn;
	$_SESSION['un']=$row['uname'];
	header('location:index1.php');
}
else{
	echo "Yor are Not Register";
	header('location:Login.php');
}
?>