<?php
    session_start();
    $con=mysqli_connect('localhost:3307','root','');
    $db=mysqli_select_db($con,'project-2');
    if(isset($_POST['submit'])){
    $username=$_POST['username'];
    $password=$_POST['password'];
    $sql="select * from admin where username='$username' and password='$password'";

    $query=mysqli_query($con,$sql);
    $row=mysqli_num_rows($query);
   	if($row==1){
   		echo "Login Sucessfully";
   		header('location:Admin Page1.php');
   	}
   	else{
   		echo "Login Failed";
   		header('location:Admin.php');
   	}
   }

?>