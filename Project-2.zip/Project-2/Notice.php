<?php include('header1.php');?>
<?php
  session_start();
  $con=mysqli_connect('localhost:3307','root','');
  mysqli_select_db($con,'project-2');
?>
<DOCTYPE html>
<html>
<head>
<title>Notice</title>
<link rel="stylesheet"  href="Notice.css">
</head>
<body>
<center>
<h1>Tour Plane</h1>

</center>

<?php
    $qry="select * from tp";
    $result=mysqli_query($con,$qry);
    while($row=mysqli_fetch_assoc($result)){
  ?>  
  
<h2 style="text-decoration: none;">Tour No : <?php echo $row['tno']; ?></h2><br><br>
<h2 style="text-decoration: none;">Place : <?php echo $row['place']; ?></h2><br><br>
<h2 style="text-decoration: none;">Tour Description: <br><br><?php echo $row['des'];?></h2><br>
<h2 style="text-decoration: none;">Total Seats:  <?php echo $row['seat'];?></h2>
<br><br><br><br>
    
  
    <?php
    }
    ?>
<h3>Please Click Flowing Link:</h3>
<h3><a href="Booking.php">$Booking Now</h3>
  
</body>
</html>